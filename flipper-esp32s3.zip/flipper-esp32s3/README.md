# Flipper Zero firmware -> ESP32-S3 (work in progress)

GPLv3, derived from https://github.com/flipperdevices/flipperzero-firmware.
Upstream is **not copied** into this repo: `tools/bootstrap.sh` fetches it with
submodules into `third_party/`, and this project layers ESP32-S3 HAL, display
backend and (stage 3) a Furi kernel shim on top. See `docs/PORTING_MATRIX.md`.

## Status
Stage 0-2 only (project, partitions, HAL, ILI9341 backend, button input). Not
yet compiled with ESP-IDF. Nothing here is a working Flipper firmware.

## Build (stage 2 bring-up)
    . $IDF_PATH/export.sh            # ESP-IDF 5.x
    idf.py set-target esp32s3
    idf.py build
    idf.py -p PORT flash monitor
Edit `components/board/include/board_config.h` to match your wiring first.
Output: `build/flipper_esp32s3.bin`. Web flashing: `tools/make_web_image.sh` writes `web/flipper_full.bin` (flash at 0x0); host `web/` over HTTPS, or push to GitHub and let `.github/workflows/build.yml` publish it to Pages.
`esptool.py --chip esp32s3 merge_bin -o flipper_full.bin @build/flash_args`.

## Hardware changes needed
Display, buttons and SD only. Sub-GHz (CC1101), NFC, 125 kHz RFID, iButton and
IR need external modules; see the matrix. Keep GPIO26-37 free (flash/PSRAM).
