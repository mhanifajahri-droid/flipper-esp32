/* SPDX-License-Identifier: GPL-3.0-or-later
 *
 * STAGE 2 BRING-UP (no Furi yet).
 * Proves, on real hardware: panel init + scaling, backlight, button wiring.
 * Furi boot (furi_init/flipper_init) is added in stage 3 once the kernel shim
 * exists. This is NOT a working Flipper firmware yet.
 */
#include <stdio.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <esp_log.h>
#include <furi_hal_resources.h>
#include <port_display.h>

#define TAG "boot"

extern void furi_hal_light_init(void);
extern void furi_hal_light_set(Light light, uint8_t value);

void app_main(void) {
    ESP_LOGI(TAG, "Flipper ESP32-S3 port - stage 2 bring-up (GPLv3)");
    furi_hal_light_init();
    port_display_init();
    port_display_fill_test_pattern();
    furi_hal_light_set(LightBacklight, 220);
    furi_hal_resources_init();

    bool prev[InputKeyMAX] = {0};
    for(;;) {
        for(size_t i = 0; i < input_pins_count; i++) {
            bool down = furi_hal_gpio_read(input_pins[i].gpio) ^ input_pins[i].inverted;
            if(down != prev[i]) {
                ESP_LOGI(TAG, "%s %s", input_pins[i].name, down ? "pressed" : "released");
                prev[i] = down;
            }
        }
        vTaskDelay(pdMS_TO_TICKS(10));
    }
}
