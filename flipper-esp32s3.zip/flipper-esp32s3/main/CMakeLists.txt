idf_component_register(SRCS "main.c" REQUIRES furi_hal_esp32 board)
