#!/usr/bin/env bash
# SPDX-License-Identifier: GPL-3.0-or-later
# Fetch the upstream Flipper firmware WITH submodules (GitHub zips omit them).
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
DEST="$ROOT/third_party/flipperzero-firmware"
REF="${FLIPPER_REF:-dev}"   # pin a tag/commit here for reproducible builds
mkdir -p "$ROOT/third_party"
if [ ! -d "$DEST/.git" ]; then
  git clone --recursive --branch "$REF" https://github.com/flipperdevices/flipperzero-firmware.git "$DEST"
else
  git -C "$DEST" fetch && git -C "$DEST" checkout "$REF" && git -C "$DEST" submodule update --init --recursive
fi
echo "Upstream at: $(git -C "$DEST" rev-parse HEAD)"
echo "Next: . \$IDF_PATH/export.sh && idf.py set-target esp32s3 && idf.py build"
