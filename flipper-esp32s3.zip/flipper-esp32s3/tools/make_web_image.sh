#!/usr/bin/env bash
# SPDX-License-Identifier: GPL-3.0-or-later
# Build and produce the single merged image for web flashing: web/flipper_full.bin
set -euo pipefail
cd "$(dirname "$0")/.."
idf.py set-target esp32s3
idf.py build
(cd build && esptool.py --chip esp32s3 merge_bin -o ../web/flipper_full.bin @flash_args)
ls -l web/flipper_full.bin
