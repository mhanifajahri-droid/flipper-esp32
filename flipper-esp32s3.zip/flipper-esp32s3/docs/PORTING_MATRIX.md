# Porting compatibility matrix

Upstream: flipperdevices/flipperzero-firmware (`dev`), GPLv3. This port is GPLv3.
Target: ESP32-S3 N16R8, 2.8" ILI9341, 6 buttons, microSD. ESP-IDF 5.x.

Status legend
- **Written, unbuilt**: code exists in this repo, syntax-checked only, never compiled with ESP-IDF or run on hardware.
- **Planned**: design decided, no code yet.
- **Unsupported**: no hardware / no sane equivalent. Will not be faked.

## Core and HAL
| Upstream module | Approach | Status |
|---|---|---|
| `furi/core` (thread, mutex, queue, pubsub, timer, event loop, record, log) | Reuse upstream; shim 12 ARM-specific files (IRQ-mode, critical sections, heap tracking, TCB access) | Planned (stage 3) |
| `furi/core/memmgr_heap.c` | Replace with `heap_caps` wrapper (internal vs PSRAM) | Planned |
| `check.c` crash/halt | Replace Cortex fault path with ESP-IDF panic | Planned |
| FreeRTOS-Kernel (vendored) | Drop; use ESP-IDF FreeRTOS (SMP fork). Set 32 priorities, 1 kHz tick | Config written (`sdkconfig.defaults`) |
| `furi_hal_gpio` | New implementation, same API | Written, unbuilt |
| `furi_hal_resources` | New pin map, same symbols for existing hardware only | Written, unbuilt |
| `furi_hal_light` | Backlight via LEDC; RGB LED unsupported | Written, unbuilt |
| `furi_hal_random` | `esp_random` | Written, unbuilt |
| `furi_hal_sd` + FatFs glue | SDSPI on SPI3; ESP-IDF FatFs with custom diskio replaces vendored FatFs | Written, unbuilt |
| `furi_hal_rtc`, `version`, `info`, `power`, `memory`, `os`, `cortex` | Reimplement subset | Planned |
| `furi_hal_i2c`, `spi`, `serial`, `pwm`, `adc` | Map to ESP-IDF drivers | Planned |
| `furi_hal_crypto` (secure enclave) | No equivalent; software AES only, no enclave keys | Partial (planned) |
| `furi_hal_bt`, STM32WB copro | NimBLE would be a different stack | Unsupported (as-is) |
| `furi_hal_usb*` | TinyUSB on native S3 USB | Planned (optional) |
| `furi_hal_infrared` | RMT + external IR LED/receiver | Planned (needs hardware) |
| `furi_hal_subghz` | Needs external CC1101 | Unsupported without module |
| `furi_hal_nfc` | Needs external ST25R3916/PN532 (different API) | Unsupported without module |
| `furi_hal_rfid` (125 kHz) | Needs external analog front end | Unsupported |
| `furi_hal_ibutton` | 1-Wire on a GPIO, needs contacts | Planned (needs hardware) |
| `furi_hal_vibro`, speaker | GPIO / LEDC or I2S if fitted | Planned (needs hardware) |

## GUI and services
| Upstream module | Approach | Status |
|---|---|---|
| `gui/canvas.c` | **Unmodified.** u8g2 glue replaced (`u8g2_glue_esp32.c`) with same symbols | Written, glue syntax-checked against real u8g2 headers |
| ILI9341 display backend | 128x64 1-bit -> RGB565, 2x scale, centred 256x128, DMA strips | Written, unbuilt |
| `gui` views/modules/scene manager | Reuse unchanged | Planned (needs Furi) |
| `input` service | Reuse unchanged (uses `input_pins[]` + gpio callbacks, both provided) | Planned (needs Furi) |
| `storage` service | Reuse; FatFs via ESP-IDF | Planned |
| `loader`, `dialogs`, `notification`, `desktop`, `archive`, `dolphin` | Reuse; notification LED/vibro paths no-op | Planned |
| `power` | Rewrite against board battery hardware | Planned |
| `cli`, `rpc` | Possible over USB-Serial-JTAG; qFlipper protocol not targeted | Planned (partial) |
| `bt` service | Unsupported with coprocessor stack | Unsupported |
| Build system (SCons/fbt, `application.fam`) | CMake + Python generator reading original `.fam` files | Planned |
| `.fap` ELF loader | ARM ELF, cannot run on Xtensa; apps linked statically | Unsupported (replaced by static linking) |
| Updater, DFU | Replaced by ESP-IDF OTA (`ota_0/ota_1`) | Planned |

## Applications
| App | Status |
|---|---|
| Archive, Settings (system, clock, desktop, notification, storage), Snake, Dolphin passport | Planned: pure software |
| GPIO, I2C/UART tools | Planned: map to S3 pins |
| Infrared | Planned: needs IR hardware |
| Bad USB, U2F, HID | Planned (optional, TinyUSB) |
| Sub-GHz, NFC, 125 kHz RFID, iButton | Unsupported without external modules. Protocol libraries may compile but cannot operate |
| JS app (mjs), BT settings, Updater | Unsupported / dropped |

## Flash layout (16 MB)
nvs 24K, otadata 8K, phy 4K, ota_0 5 MB, ota_1 5 MB, storage FAT 5.75 MB (ends 0xFE0000).

## Overall verdict
**Not a working port yet.** Stages 0-2 are written but not compiled. No Furi, no GUI, no application runs.
