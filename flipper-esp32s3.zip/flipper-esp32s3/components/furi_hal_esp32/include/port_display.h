/* SPDX-License-Identifier: GPL-3.0-or-later
 * ILI9341 backend. The Flipper UI renders into a 128x64 1-bit buffer (u8g2);
 * this module expands it to RGB565, scales it BOARD_UI_SCALE x and pushes it
 * to the panel over SPI DMA.
 */
#pragma once
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif

#define PORT_UI_W 128
#define PORT_UI_H 64

void port_display_init(void);
/* Update the shadow 1-bit framebuffer (vertical-LSB tile layout is already
 * decoded by the u8g2 glue into one byte per pixel: 0/1). */
void port_display_blit_tile(uint8_t x, uint8_t y, const uint8_t* col8_bytes);
void port_display_flush(void);
void port_display_fill_test_pattern(void);

#ifdef __cplusplus
}
#endif
