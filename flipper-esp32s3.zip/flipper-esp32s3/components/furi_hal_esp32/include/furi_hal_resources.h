/* SPDX-License-Identifier: GPL-3.0-or-later
 * Pin resources for the ESP32-S3 board. Mirrors the symbols of upstream
 * targets/f7/furi_hal/furi_hal_resources.h for the hardware that exists here.
 * Symbols for absent hardware (CC1101, NFC, RFID, iButton, IR, vibro) are
 * intentionally NOT defined: code needing them must fail to link, not fake it.
 */
#pragma once
#include <stddef.h>
#include <stdbool.h>
#include <stdint.h>
#include <furi_hal_gpio.h>

#ifdef __cplusplus
extern "C" {
#endif

#define INPUT_DEBOUNCE_TICKS 4

typedef enum {
    InputKeyUp,
    InputKeyDown,
    InputKeyRight,
    InputKeyLeft,
    InputKeyOk,
    InputKeyBack,
    InputKeyMAX,
} InputKey;

typedef enum {
    LightRed = (1 << 0),
    LightGreen = (1 << 1),
    LightBlue = (1 << 2),
    LightBacklight = (1 << 3),
} Light;

typedef struct {
    const GpioPin* gpio;
    const InputKey key;
    const bool inverted;
    const char* name;
} InputPin;

extern const InputPin input_pins[];
extern const size_t input_pins_count;

extern const GpioPin gpio_display_cs;
extern const GpioPin gpio_display_rst_n;
extern const GpioPin gpio_display_di;
extern const GpioPin gpio_display_bl;
extern const GpioPin gpio_sdcard_cs;
extern const GpioPin gpio_sdcard_cd;

extern const GpioPin gpio_button_up;
extern const GpioPin gpio_button_down;
extern const GpioPin gpio_button_right;
extern const GpioPin gpio_button_left;
extern const GpioPin gpio_button_ok;
extern const GpioPin gpio_button_back;

void furi_hal_resources_init(void);

#ifdef __cplusplus
}
#endif
