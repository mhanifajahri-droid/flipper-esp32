/* SPDX-License-Identifier: GPL-3.0-or-later
 * ESP32-S3 implementation of the Flipper furi_hal_gpio API.
 * Same function names/enums as targets/f7/furi_hal/furi_hal_gpio.h so that
 * upstream services (e.g. the input service) compile unchanged.
 */
#pragma once
#include <stdbool.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef void (*GpioExtiCallback)(void* ctx);

typedef enum {
    GpioModeInput,
    GpioModeOutputPushPull,
    GpioModeOutputOpenDrain,
    GpioModeAltFunctionPushPull, /* unsupported: treated as push-pull output */
    GpioModeAltFunctionOpenDrain, /* unsupported: treated as open-drain output */
    GpioModeAnalog,
    GpioModeInterruptRise,
    GpioModeInterruptFall,
    GpioModeInterruptRiseFall,
    GpioModeEventRise, /* unsupported: treated as interrupt */
    GpioModeEventFall,
    GpioModeEventRiseFall,
} GpioMode;

typedef enum { GpioPullNo, GpioPullUp, GpioPullDown } GpioPull;
typedef enum { GpioSpeedLow, GpioSpeedMedium, GpioSpeedHigh, GpioSpeedVeryHigh } GpioSpeed;
/* STM32 alternate functions have no ESP32 equivalent; routing is done by the
 * ESP-IDF peripheral drivers. Kept only so upstream call sites compile. */
typedef enum { GpioAltFnUnused = 16 } GpioAltFn;

/* ESP32-S3: a pin is just a GPIO number. */
typedef struct {
    int num;
} GpioPin;

void furi_hal_gpio_init_simple(const GpioPin* gpio, const GpioMode mode);
void furi_hal_gpio_init(
    const GpioPin* gpio, const GpioMode mode, const GpioPull pull, const GpioSpeed speed);
void furi_hal_gpio_init_ex(
    const GpioPin* gpio,
    const GpioMode mode,
    const GpioPull pull,
    const GpioSpeed speed,
    const GpioAltFn alt_fn);
void furi_hal_gpio_add_int_callback(const GpioPin* gpio, GpioExtiCallback cb, void* ctx);
void furi_hal_gpio_enable_int_callback(const GpioPin* gpio);
void furi_hal_gpio_disable_int_callback(const GpioPin* gpio);
void furi_hal_gpio_remove_int_callback(const GpioPin* gpio);
void furi_hal_gpio_write(const GpioPin* gpio, const bool state);
bool furi_hal_gpio_read(const GpioPin* gpio);

#ifdef __cplusplus
}
#endif
