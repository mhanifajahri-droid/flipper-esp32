# SPDX-License-Identifier: GPL-3.0-or-later
# Stage 0-2 sources need only ESP-IDF. Sources that include upstream Furi
# headers (SD HAL, u8g2 glue) are enabled with -DFLIPPER_ENABLE_FURI=ON after
# tools/bootstrap.sh has fetched upstream and the Furi shim (stage 3) exists.
set(FLIPPER_SRC "${PROJECT_DIR}/third_party/flipperzero-firmware" CACHE PATH "Upstream tree")
option(FLIPPER_ENABLE_FURI "Build parts that depend on upstream Furi/u8g2" OFF)

set(srcs
    "src/furi_hal_gpio.c"
    "src/furi_hal_resources.c"
    "src/furi_hal_light.c"
    "src/furi_hal_random.c"
    "src/port_display.c")
set(incs "include")

if(FLIPPER_ENABLE_FURI)
    list(APPEND srcs "src/furi_hal_sd.c" "src/u8g2_glue_esp32.c")
    list(APPEND incs
        "${FLIPPER_SRC}"
        "${FLIPPER_SRC}/furi"
        "${FLIPPER_SRC}/targets/furi_hal_include"
        "${FLIPPER_SRC}/lib/u8g2")
endif()

idf_component_register(
    SRCS ${srcs}
    INCLUDE_DIRS ${incs}
    REQUIRES board driver esp_driver_gpio esp_driver_spi esp_driver_ledc esp_lcd
             sdmmc fatfs esp_timer esp_hw_support
)
