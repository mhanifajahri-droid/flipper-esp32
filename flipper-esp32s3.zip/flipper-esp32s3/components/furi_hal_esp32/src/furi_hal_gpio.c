/* SPDX-License-Identifier: GPL-3.0-or-later */
#include <furi_hal_gpio.h>
#include <driver/gpio.h>
#include <esp_attr.h>
#include <stddef.h>

#define MAX_GPIO GPIO_NUM_MAX

typedef struct {
    GpioExtiCallback cb;
    void* ctx;
} IntSlot;

static IntSlot slots[MAX_GPIO];
static bool isr_service_ready = false;

static void IRAM_ATTR gpio_isr(void* arg) {
    IntSlot* s = arg;
    if(s->cb) s->cb(s->ctx);
}

static void ensure_isr_service(void) {
    if(!isr_service_ready) {
        /* Ignore ESP_ERR_INVALID_STATE if another component installed it. */
        gpio_install_isr_service(0);
        isr_service_ready = true;
    }
}

void furi_hal_gpio_init(
    const GpioPin* gpio, const GpioMode mode, const GpioPull pull, const GpioSpeed speed) {
    (void)speed; /* ESP32 GPIO matrix has no slew-rate setting at this level */
    gpio_config_t c = {
        .pin_bit_mask = 1ULL << gpio->num,
        .pull_up_en = pull == GpioPullUp ? GPIO_PULLUP_ENABLE : GPIO_PULLUP_DISABLE,
        .pull_down_en = pull == GpioPullDown ? GPIO_PULLDOWN_ENABLE : GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE,
    };
    switch(mode) {
    case GpioModeInput:
    case GpioModeAnalog:
        c.mode = GPIO_MODE_INPUT;
        break;
    case GpioModeOutputPushPull:
    case GpioModeAltFunctionPushPull:
        c.mode = GPIO_MODE_INPUT_OUTPUT; /* keeps read-back working */
        break;
    case GpioModeOutputOpenDrain:
    case GpioModeAltFunctionOpenDrain:
        c.mode = GPIO_MODE_INPUT_OUTPUT_OD;
        break;
    case GpioModeInterruptRise:
    case GpioModeEventRise:
        c.mode = GPIO_MODE_INPUT;
        c.intr_type = GPIO_INTR_POSEDGE;
        break;
    case GpioModeInterruptFall:
    case GpioModeEventFall:
        c.mode = GPIO_MODE_INPUT;
        c.intr_type = GPIO_INTR_NEGEDGE;
        break;
    case GpioModeInterruptRiseFall:
    case GpioModeEventRiseFall:
        c.mode = GPIO_MODE_INPUT;
        c.intr_type = GPIO_INTR_ANYEDGE;
        break;
    }
    gpio_config(&c);
}

void furi_hal_gpio_init_simple(const GpioPin* gpio, const GpioMode mode) {
    furi_hal_gpio_init(gpio, mode, GpioPullNo, GpioSpeedLow);
}

void furi_hal_gpio_init_ex(
    const GpioPin* gpio,
    const GpioMode mode,
    const GpioPull pull,
    const GpioSpeed speed,
    const GpioAltFn alt_fn) {
    (void)alt_fn;
    furi_hal_gpio_init(gpio, mode, pull, speed);
}

void furi_hal_gpio_add_int_callback(const GpioPin* gpio, GpioExtiCallback cb, void* ctx) {
    ensure_isr_service();
    slots[gpio->num].cb = cb;
    slots[gpio->num].ctx = ctx;
    gpio_isr_handler_add(gpio->num, gpio_isr, &slots[gpio->num]);
}

void furi_hal_gpio_enable_int_callback(const GpioPin* gpio) {
    gpio_intr_enable(gpio->num);
}

void furi_hal_gpio_disable_int_callback(const GpioPin* gpio) {
    gpio_intr_disable(gpio->num);
}

void furi_hal_gpio_remove_int_callback(const GpioPin* gpio) {
    gpio_isr_handler_remove(gpio->num);
    slots[gpio->num].cb = NULL;
    slots[gpio->num].ctx = NULL;
}

void furi_hal_gpio_write(const GpioPin* gpio, const bool state) {
    gpio_set_level(gpio->num, state ? 1 : 0);
}

bool furi_hal_gpio_read(const GpioPin* gpio) {
    return gpio_get_level(gpio->num) != 0;
}
