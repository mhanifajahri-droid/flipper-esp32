/* SPDX-License-Identifier: GPL-3.0-or-later
 * microSD over SPI (SPI3) using ESP-IDF sdspi + sdmmc.
 * Implements upstream targets/furi_hal_include/furi_hal_sd.h so the original
 * storage service (storage_ext.c) is reused unchanged.
 *
 * Upstream links its own vendored FatFs. Here ESP-IDF's FatFs (same ChaN API)
 * is used instead, and furi_hal_sd_register_fatfs() installs a diskio driver
 * that forwards to this HAL, mirroring targets/f7/fatfs/user_diskio.c.
 */
#include <furi.h>
#include <furi_hal_sd.h>
#include <board_config.h>
#include <string.h>
#include <driver/spi_common.h>
#include <driver/sdspi_host.h>
#include <sdmmc_cmd.h>
#include <diskio_impl.h>
#include <esp_log.h>
#include <driver/gpio.h>

#define TAG "furi_hal_sd"

static sdmmc_card_t* card = NULL;
static bool bus_ready = false;
static sdspi_dev_handle_t sd_handle = -1;

void furi_hal_sd_presence_init(void) {
#if BOARD_SD_CD >= 0
    gpio_config_t c = {
        .pin_bit_mask = 1ULL << BOARD_SD_CD,
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_ENABLE,
    };
    gpio_config(&c);
#endif
}

bool furi_hal_sd_is_present(void) {
#if BOARD_SD_CD >= 0
    return gpio_get_level(BOARD_SD_CD) == 0;
#else
    return true; /* no CD switch: try to mount and let init() report failure */
#endif
}

uint8_t furi_hal_sd_max_mount_retry_count(void) {
    return 10;
}

static void sd_teardown(void) {
    if(card) {
        free(card);
        card = NULL;
    }
    if(sd_handle >= 0) {
        sdspi_host_remove_device(sd_handle);
        sd_handle = -1;
        sdspi_host_deinit();
    }
}

FuriStatus furi_hal_sd_init(bool power_reset) {
    (void)power_reset; /* no switched SD supply on this board */
    sd_teardown();

    if(!bus_ready) {
        spi_bus_config_t bus = {
            .mosi_io_num = BOARD_SD_MOSI,
            .miso_io_num = BOARD_SD_MISO,
            .sclk_io_num = BOARD_SD_SCLK,
            .quadwp_io_num = -1,
            .quadhd_io_num = -1,
            .max_transfer_sz = 4096,
        };
        esp_err_t e = spi_bus_initialize(BOARD_SD_HOST, &bus, SDSPI_DEFAULT_DMA);
        if(e != ESP_OK) {
            ESP_LOGE(TAG, "spi_bus_initialize: %s", esp_err_to_name(e));
            return FuriStatusError;
        }
        bus_ready = true;
    }

    sdmmc_host_t host = SDSPI_HOST_DEFAULT();
    host.slot = BOARD_SD_HOST;
    host.max_freq_khz = BOARD_SD_SPI_KHZ;
    sdspi_device_config_t dev = SDSPI_DEVICE_CONFIG_DEFAULT();
    dev.host_id = BOARD_SD_HOST;
    dev.gpio_cs = BOARD_SD_CS;

    if(sdspi_host_init() != ESP_OK) return FuriStatusError;
    if(sdspi_host_init_device(&dev, &sd_handle) != ESP_OK) {
        sdspi_host_deinit();
        return FuriStatusError;
    }
    host.slot = sd_handle;

    card = calloc(1, sizeof(sdmmc_card_t));
    if(!card) return FuriStatusError;
    esp_err_t e = sdmmc_card_init(&host, card);
    if(e != ESP_OK) {
        ESP_LOGW(TAG, "card init failed: %s", esp_err_to_name(e));
        sd_teardown();
        return FuriStatusError;
    }
    return FuriStatusOk;
}

FuriStatus furi_hal_sd_read_blocks(uint32_t* buff, uint32_t sector, uint32_t count) {
    if(!card) return FuriStatusError;
    return sdmmc_read_sectors(card, buff, sector, count) == ESP_OK ? FuriStatusOk :
                                                                      FuriStatusError;
}

FuriStatus furi_hal_sd_write_blocks(const uint32_t* buff, uint32_t sector, uint32_t count) {
    if(!card) return FuriStatusError;
    return sdmmc_write_sectors(card, buff, sector, count) == ESP_OK ? FuriStatusOk :
                                                                       FuriStatusError;
}

FuriStatus furi_hal_sd_info(FuriHalSdInfo* info) {
    if(!card || !info) return FuriStatusError;
    memset(info, 0, sizeof(*info));
    info->logical_block_count = card->csd.capacity;
    info->logical_block_size = card->csd.sector_size;
    info->block_size = card->csd.sector_size;
    info->capacity = (uint64_t)card->csd.capacity * card->csd.sector_size;
    info->manufacturer_id = card->cid.mfg_id;
    info->oem_id[0] = (char)(card->cid.oem_id >> 8);
    info->oem_id[1] = (char)(card->cid.oem_id & 0xFF);
    memcpy(info->product_name, card->cid.name, sizeof(info->product_name) - 1);
    info->product_revision_major = card->cid.revision >> 4;
    info->product_revision_minor = card->cid.revision & 0x0F;
    info->product_serial_number = card->cid.serial;
    /* esp-idf stores the raw CID date field: [11:4]=year-2000, [3:0]=month */
    info->manufacturing_month = card->cid.date & 0x0F;
    info->manufacturing_year = 2000 + ((card->cid.date >> 4) & 0xFF);
    return FuriStatusOk;
}

FuriStatus furi_hal_sd_get_card_state(void) {
    if(!card) return FuriStatusError;
    return sdmmc_get_status(card) == ESP_OK ? FuriStatusOk : FuriStatusError;
}

/* ---- FatFs diskio glue (ESP-IDF FatFs <-> furi_hal_sd), drive "0:" ---- */
static DSTATUS dio_init(BYTE pdrv) {
    (void)pdrv;
    return card ? 0 : STA_NOINIT;
}
static DSTATUS dio_status(BYTE pdrv) {
    (void)pdrv;
    return furi_hal_sd_get_card_state() == FuriStatusOk ? 0 : STA_NOINIT;
}
static DRESULT dio_read(BYTE pdrv, BYTE* buf, DWORD sector, UINT count) {
    (void)pdrv;
    return furi_hal_sd_read_blocks((uint32_t*)buf, sector, count) == FuriStatusOk ? RES_OK :
                                                                                     RES_ERROR;
}
static DRESULT dio_write(BYTE pdrv, const BYTE* buf, DWORD sector, UINT count) {
    (void)pdrv;
    return furi_hal_sd_write_blocks((const uint32_t*)buf, sector, count) == FuriStatusOk ?
               RES_OK :
               RES_ERROR;
}
static DRESULT dio_ioctl(BYTE pdrv, BYTE cmd, void* buf) {
    (void)pdrv;
    if(!card) return RES_NOTRDY;
    switch(cmd) {
    case CTRL_SYNC:
        return RES_OK;
    case GET_SECTOR_COUNT:
        *(DWORD*)buf = card->csd.capacity;
        return RES_OK;
    case GET_SECTOR_SIZE:
        *(WORD*)buf = card->csd.sector_size;
        return RES_OK;
    case GET_BLOCK_SIZE:
        *(DWORD*)buf = 1;
        return RES_OK;
    default:
        return RES_PARERR;
    }
}

void furi_hal_sd_register_fatfs(void) {
    static const ff_diskio_impl_t impl = {
        .init = dio_init,
        .status = dio_status,
        .read = dio_read,
        .write = dio_write,
        .ioctl = dio_ioctl,
    };
    ff_diskio_register(0, &impl);
}
