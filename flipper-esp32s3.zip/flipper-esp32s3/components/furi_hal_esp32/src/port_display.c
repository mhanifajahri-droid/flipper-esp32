/* SPDX-License-Identifier: GPL-3.0-or-later */
#include <port_display.h>
#include <board_config.h>
#include <string.h>
#include <stdlib.h>
#include <driver/gpio.h>
#include <driver/spi_master.h>
#include <esp_lcd_panel_io.h>
#include <esp_heap_caps.h>
#include <esp_log.h>
#include <esp_rom_sys.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>

#define TAG "port_display"

#define OUT_W (PORT_UI_W * BOARD_UI_SCALE)
#define OUT_H (PORT_UI_H * BOARD_UI_SCALE)
#define OFF_X ((BOARD_LCD_W - OUT_W) / 2)
#define OFF_Y ((BOARD_LCD_H - OUT_H) / 2)
#define STRIP_SRC_ROWS 8 /* source rows per DMA strip */

_Static_assert(OUT_W <= BOARD_LCD_W && OUT_H <= BOARD_LCD_H, "UI does not fit panel");

static esp_lcd_panel_io_handle_t io;
static uint8_t* shadow; /* 128*64, one byte per pixel (0/1) */
static uint16_t* strip; /* DMA-capable strip buffer, big-endian RGB565 */

static inline uint16_t be16(uint16_t v) {
    return (uint16_t)((v >> 8) | (v << 8));
}

static void cmd(uint8_t c, const void* data, size_t len) {
    esp_lcd_panel_io_tx_param(io, c, data, len);
}

static void set_window(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1) {
    uint8_t c[4] = {x0 >> 8, x0 & 0xFF, x1 >> 8, x1 & 0xFF};
    cmd(0x2A, c, 4);
    uint8_t r[4] = {y0 >> 8, y0 & 0xFF, y1 >> 8, y1 & 0xFF};
    cmd(0x2B, r, 4);
}

static void fill_rect(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint16_t color565) {
    if(!w || !h) return;
    const uint16_t px = be16(color565);
    const size_t line_px = w;
    for(uint16_t row = 0; row < h;) {
        uint16_t rows = (uint16_t)((STRIP_SRC_ROWS * BOARD_UI_SCALE * OUT_W) / line_px);
        if(rows == 0) rows = 1;
        if(rows > h - row) rows = h - row;
        for(size_t i = 0; i < (size_t)rows * line_px; i++) strip[i] = px;
        set_window(x, y + row, x + w - 1, y + row + rows - 1);
        esp_lcd_panel_io_tx_color(io, 0x2C, strip, (size_t)rows * line_px * 2);
        row += rows;
    }
}

void port_display_init(void) {
    spi_bus_config_t bus = {
        .mosi_io_num = BOARD_LCD_MOSI,
        .miso_io_num = BOARD_LCD_MISO,
        .sclk_io_num = BOARD_LCD_SCLK,
        .quadwp_io_num = -1,
        .quadhd_io_num = -1,
        .max_transfer_sz = STRIP_SRC_ROWS * BOARD_UI_SCALE * OUT_W * 2,
    };
    ESP_ERROR_CHECK(spi_bus_initialize(BOARD_LCD_HOST, &bus, SPI_DMA_CH_AUTO));

    esp_lcd_panel_io_spi_config_t io_cfg = {
        .dc_gpio_num = BOARD_LCD_DC,
        .cs_gpio_num = BOARD_LCD_CS,
        .pclk_hz = BOARD_LCD_SPI_HZ,
        .lcd_cmd_bits = 8,
        .lcd_param_bits = 8,
        .spi_mode = 0,
        .trans_queue_depth = 4,
    };
    ESP_ERROR_CHECK(esp_lcd_new_panel_io_spi((esp_lcd_spi_bus_handle_t)BOARD_LCD_HOST, &io_cfg, &io));

    shadow = heap_caps_calloc(PORT_UI_W * PORT_UI_H, 1, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if(!shadow) shadow = calloc(PORT_UI_W * PORT_UI_H, 1);
    strip = heap_caps_malloc(
        STRIP_SRC_ROWS * BOARD_UI_SCALE * OUT_W * 2, MALLOC_CAP_DMA | MALLOC_CAP_INTERNAL);
    configASSERT(shadow && strip);

    /* Hardware reset */
    gpio_config_t rst = {.pin_bit_mask = 1ULL << BOARD_LCD_RST, .mode = GPIO_MODE_OUTPUT};
    gpio_config(&rst);
    gpio_set_level(BOARD_LCD_RST, 0);
    vTaskDelay(pdMS_TO_TICKS(20));
    gpio_set_level(BOARD_LCD_RST, 1);
    vTaskDelay(pdMS_TO_TICKS(120));

    /* ILI9341 init (standard sequence, 16bpp, landscape per BOARD_LCD_MADCTL) */
    cmd(0x01, NULL, 0); /* SWRESET */
    vTaskDelay(pdMS_TO_TICKS(120));
    cmd(0xCF, (uint8_t[]){0x00, 0xC1, 0x30}, 3);
    cmd(0xED, (uint8_t[]){0x64, 0x03, 0x12, 0x81}, 4);
    cmd(0xE8, (uint8_t[]){0x85, 0x00, 0x78}, 3);
    cmd(0xCB, (uint8_t[]){0x39, 0x2C, 0x00, 0x34, 0x02}, 5);
    cmd(0xF7, (uint8_t[]){0x20}, 1);
    cmd(0xEA, (uint8_t[]){0x00, 0x00}, 2);
    cmd(0xC0, (uint8_t[]){0x23}, 1); /* power ctrl 1 */
    cmd(0xC1, (uint8_t[]){0x10}, 1); /* power ctrl 2 */
    cmd(0xC5, (uint8_t[]){0x3E, 0x28}, 2); /* VCOM 1 */
    cmd(0xC7, (uint8_t[]){0x86}, 1); /* VCOM 2 */
    cmd(0x36, (uint8_t[]){BOARD_LCD_MADCTL}, 1);
    cmd(0x3A, (uint8_t[]){0x55}, 1); /* 16 bpp */
    cmd(0xB1, (uint8_t[]){0x00, 0x18}, 2); /* frame rate */
    cmd(0xB6, (uint8_t[]){0x08, 0x82, 0x27}, 3);
    cmd(0xF2, (uint8_t[]){0x00}, 1);
    cmd(0x26, (uint8_t[]){0x01}, 1); /* gamma curve */
    cmd(0xE0, (uint8_t[]){0x0F, 0x31, 0x2B, 0x0C, 0x0E, 0x08, 0x4E, 0xF1, 0x37, 0x07, 0x10, 0x03, 0x0E, 0x09, 0x00}, 15);
    cmd(0xE1, (uint8_t[]){0x00, 0x0E, 0x14, 0x03, 0x11, 0x07, 0x31, 0xC1, 0x48, 0x08, 0x0F, 0x0C, 0x31, 0x36, 0x0F}, 15);
    cmd(BOARD_LCD_INVERT ? 0x21 : 0x20, NULL, 0);
    cmd(0x11, NULL, 0); /* sleep out */
    vTaskDelay(pdMS_TO_TICKS(120));
    cmd(0x29, NULL, 0); /* display on */

    fill_rect(0, 0, BOARD_LCD_W, BOARD_LCD_H, BOARD_COLOR_BORDER);
    ESP_LOGI(TAG, "ILI9341 %dx%d, UI %dx%d @ (%d,%d)", BOARD_LCD_W, BOARD_LCD_H, OUT_W, OUT_H, OFF_X, OFF_Y);
}

void port_display_blit_tile(uint8_t x, uint8_t y, const uint8_t* col8_bytes) {
    /* u8g2 vertical_top_lsb tile: 8 bytes, each byte = one column, LSB = top. */
    for(int c = 0; c < 8; c++) {
        uint8_t b = col8_bytes[c];
        for(int bit = 0; bit < 8; bit++) {
            shadow[(y + bit) * PORT_UI_W + x + c] = (b >> bit) & 1;
        }
    }
}

void port_display_flush(void) {
    const uint16_t fg = be16(BOARD_COLOR_FG), bg = be16(BOARD_COLOR_BG);
    for(int sy = 0; sy < PORT_UI_H; sy += STRIP_SRC_ROWS) {
        uint16_t* d = strip;
        for(int r = 0; r < STRIP_SRC_ROWS; r++) {
            const uint8_t* src = shadow + (sy + r) * PORT_UI_W;
            uint16_t* line = d;
            for(int x = 0; x < PORT_UI_W; x++) {
                uint16_t v = src[x] ? fg : bg;
                for(int k = 0; k < BOARD_UI_SCALE; k++) *d++ = v;
            }
            for(int k = 1; k < BOARD_UI_SCALE; k++) {
                memcpy(d, line, OUT_W * 2);
                d += OUT_W;
            }
        }
        set_window(OFF_X, OFF_Y + sy * BOARD_UI_SCALE, OFF_X + OUT_W - 1,
                   OFF_Y + (sy + STRIP_SRC_ROWS) * BOARD_UI_SCALE - 1);
        esp_lcd_panel_io_tx_color(io, 0x2C, strip, OUT_W * STRIP_SRC_ROWS * BOARD_UI_SCALE * 2);
    }
}

void port_display_fill_test_pattern(void) {
    for(int y = 0; y < PORT_UI_H; y++)
        for(int x = 0; x < PORT_UI_W; x++)
            shadow[y * PORT_UI_W + x] =
                (x == 0 || y == 0 || x == PORT_UI_W - 1 || y == PORT_UI_H - 1 || x == y ||
                 ((x / 8 + y / 8) & 1 && y > 40));
    port_display_flush();
}
