/* SPDX-License-Identifier: GPL-3.0-or-later
 * Backlight only (LEDC PWM). The RGB notification LED does not exist on this
 * board: LightRed/Green/Blue are accepted and ignored.
 */
#include <furi_hal_resources.h>
#include <board_config.h>
#include <driver/ledc.h>

#define BL_TIMER   LEDC_TIMER_0
#define BL_CHANNEL LEDC_CHANNEL_0
#define BL_MODE    LEDC_LOW_SPEED_MODE

static bool inited = false;

void furi_hal_light_init(void) {
    if(inited) return;
    ledc_timer_config_t t = {
        .speed_mode = BL_MODE,
        .duty_resolution = LEDC_TIMER_8_BIT,
        .timer_num = BL_TIMER,
        .freq_hz = 5000,
        .clk_cfg = LEDC_AUTO_CLK,
    };
    ledc_timer_config(&t);
    ledc_channel_config_t c = {
        .gpio_num = BOARD_LCD_BL,
        .speed_mode = BL_MODE,
        .channel = BL_CHANNEL,
        .timer_sel = BL_TIMER,
        .duty = 0,
        .hpoint = 0,
    };
    ledc_channel_config(&c);
    inited = true;
}

void furi_hal_light_set(Light light, uint8_t value) {
    if(!(light & LightBacklight)) return; /* no RGB LED on this board */
    if(!inited) furi_hal_light_init();
    ledc_set_duty(BL_MODE, BL_CHANNEL, value);
    ledc_update_duty(BL_MODE, BL_CHANNEL);
}

/* LED blink/sequence: not supported (no RGB LED). */
void furi_hal_light_blink_start(Light l, uint8_t b, uint16_t on, uint16_t period) {
    (void)l; (void)b; (void)on; (void)period;
}
void furi_hal_light_blink_stop(void) {}
void furi_hal_light_blink_set_color(Light l) { (void)l; }
void furi_hal_light_sequence(const char* s) { (void)s; }
