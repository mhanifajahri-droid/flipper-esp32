/* SPDX-License-Identifier: GPL-3.0-or-later
 * Hardware RNG (true random when Wi-Fi/BT RF is on; otherwise pseudo-random
 * seeded from entropy sources - see esp_random() docs).
 */
#include <esp_random.h>
#include <stdint.h>

void furi_hal_random_init(void) {}
uint32_t furi_hal_random_get(void) {
    return esp_random();
}
void furi_hal_random_fill_buf(uint8_t* buf, uint32_t len) {
    esp_fill_random(buf, len);
}
