/* SPDX-License-Identifier: GPL-3.0-or-later
 * Replacement for upstream lib/u8g2/u8g2_glue.c (ST756x over STM32 SPI).
 * Exports the SAME symbols so applications/services/gui/canvas.c compiles
 * unmodified; only the display callback is different: it feeds the 128x64
 * u8g2 tile buffer to the ILI9341 backend instead of an ST7565.
 * Exclude lib/u8g2/u8g2_glue.c from the build when using this file.
 */
#include <u8g2_glue.h>
#include <port_display.h>

static const u8x8_display_info_t display_info = {
    .chip_enable_level = 0,
    .chip_disable_level = 1,
    .post_chip_enable_wait_ns = 0,
    .pre_chip_disable_wait_ns = 0,
    .reset_pulse_width_ms = 0,
    .post_reset_wait_ms = 0,
    .sda_setup_time_ns = 0,
    .sck_pulse_width_ns = 0,
    .sck_clock_hz = 1000000UL,
    .spi_mode = 0,
    .i2c_bus_clock_100kHz = 1,
    .data_setup_time_ns = 0,
    .write_pulse_width_ns = 0,
    .tile_width = PORT_UI_W / 8,
    .tile_height = PORT_UI_H / 8,
    .default_x_offset = 0,
    .flipmode_x_offset = 0,
    .pixel_width = PORT_UI_W,
    .pixel_height = PORT_UI_H,
};

/* The u8x8 byte/GPIO layers are unused: the display callback talks to the panel
 * directly, so these always report success. */
uint8_t u8g2_gpio_and_delay_stm32(u8x8_t* u8x8, uint8_t msg, uint8_t arg_int, void* arg_ptr) {
    (void)u8x8; (void)msg; (void)arg_int; (void)arg_ptr;
    return 1;
}
uint8_t u8x8_hw_spi_stm32(u8x8_t* u8x8, uint8_t msg, uint8_t arg_int, void* arg_ptr) {
    (void)u8x8; (void)msg; (void)arg_int; (void)arg_ptr;
    return 1;
}

static uint8_t u8x8_d_tft_flipper(u8x8_t* u8x8, uint8_t msg, uint8_t arg_int, void* arg_ptr) {
    switch(msg) {
    case U8X8_MSG_DISPLAY_SETUP_MEMORY:
        u8x8_d_helper_display_setup_memory(u8x8, &display_info);
        return 1;
    case U8X8_MSG_DISPLAY_INIT:
        port_display_init();
        return 1;
    case U8X8_MSG_DISPLAY_DRAW_TILE: {
        u8x8_tile_t* t = (u8x8_tile_t*)arg_ptr;
        uint8_t x = t->x_pos;
        do {
            const uint8_t* p = t->tile_ptr;
            for(uint8_t c = 0; c < t->cnt; c++, p += 8) {
                port_display_blit_tile((uint8_t)((x + c) * 8), (uint8_t)(t->y_pos * 8), p);
            }
            x += t->cnt;
            arg_int--;
        } while(arg_int > 0);
        return 1;
    }
    case U8X8_MSG_DISPLAY_REFRESH:
        port_display_flush();
        return 1;
    case U8X8_MSG_DISPLAY_SET_POWER_SAVE:
    case U8X8_MSG_DISPLAY_SET_FLIP_MODE:
    case U8X8_MSG_DISPLAY_SET_CONTRAST:
        return 1; /* handled via backlight / MADCTL, not u8g2 */
    default:
        return 0;
    }
}

void u8g2_Setup_st756x_flipper(
    u8g2_t* u8g2,
    const u8g2_cb_t* rotation,
    u8x8_msg_cb byte_cb,
    u8x8_msg_cb gpio_and_delay_cb) {
    uint8_t tile_buf_height;
    uint8_t* buf;
    u8g2_SetupDisplay(u8g2, u8x8_d_tft_flipper, u8x8_cad_001, byte_cb, gpio_and_delay_cb);
    buf = u8g2_m_16_8_f(&tile_buf_height);
    u8g2_SetupBuffer(u8g2, buf, tile_buf_height, u8g2_ll_hvline_vertical_top_lsb, rotation);
}

/* ST756x contrast API is meaningless on a TFT. Kept so the settings app links. */
void u8x8_d_st756x_init(u8x8_t* u8x8, uint8_t contrast, uint8_t regulation_ratio, bool bias) {
    (void)u8x8; (void)contrast; (void)regulation_ratio; (void)bias;
}
void u8x8_d_st756x_set_contrast(u8x8_t* u8x8, int8_t contrast_offset) {
    (void)u8x8; (void)contrast_offset;
}
