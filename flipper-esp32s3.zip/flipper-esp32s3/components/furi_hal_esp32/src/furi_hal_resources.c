/* SPDX-License-Identifier: GPL-3.0-or-later */
#include <furi_hal_resources.h>
#include <board_config.h>

const GpioPin gpio_display_cs = {.num = BOARD_LCD_CS};
const GpioPin gpio_display_rst_n = {.num = BOARD_LCD_RST};
const GpioPin gpio_display_di = {.num = BOARD_LCD_DC};
const GpioPin gpio_display_bl = {.num = BOARD_LCD_BL};
const GpioPin gpio_sdcard_cs = {.num = BOARD_SD_CS};
const GpioPin gpio_sdcard_cd = {.num = BOARD_SD_CD};

const GpioPin gpio_button_up = {.num = BOARD_BTN_UP};
const GpioPin gpio_button_down = {.num = BOARD_BTN_DOWN};
const GpioPin gpio_button_right = {.num = BOARD_BTN_RIGHT};
const GpioPin gpio_button_left = {.num = BOARD_BTN_LEFT};
const GpioPin gpio_button_ok = {.num = BOARD_BTN_OK};
const GpioPin gpio_button_back = {.num = BOARD_BTN_BACK};

/* All buttons are active-low here, so every entry is inverted=true
 * (upstream Flipper has OK non-inverted; its wiring differs). */
const InputPin input_pins[] = {
    {.gpio = &gpio_button_up, .key = InputKeyUp, .inverted = true, .name = "Up"},
    {.gpio = &gpio_button_down, .key = InputKeyDown, .inverted = true, .name = "Down"},
    {.gpio = &gpio_button_right, .key = InputKeyRight, .inverted = true, .name = "Right"},
    {.gpio = &gpio_button_left, .key = InputKeyLeft, .inverted = true, .name = "Left"},
    {.gpio = &gpio_button_ok, .key = InputKeyOk, .inverted = true, .name = "OK"},
    {.gpio = &gpio_button_back, .key = InputKeyBack, .inverted = true, .name = "Back"},
};
const size_t input_pins_count = sizeof(input_pins) / sizeof(input_pins[0]);

void furi_hal_resources_init(void) {
    for(size_t i = 0; i < input_pins_count; i++) {
        furi_hal_gpio_init(
            input_pins[i].gpio, GpioModeInterruptRiseFall, GpioPullUp, GpioSpeedLow);
    }
}
