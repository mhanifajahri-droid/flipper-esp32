/* SPDX-License-Identifier: GPL-3.0-or-later
 * Board pin map: ESP32-S3 N16R8 + 2.8" ILI9341 + 6 buttons + microSD.
 * EDIT THESE TO MATCH YOUR WIRING. Defaults avoid:
 *   GPIO26-37  (flash / octal PSRAM on N16R8), GPIO0/3/45/46 (strapping),
 *   GPIO19/20  (native USB D-/D+).
 */
#pragma once

/* ---- Display: ILI9341 on SPI2 ---- */
#define BOARD_LCD_HOST       SPI2_HOST
#define BOARD_LCD_SCLK       12
#define BOARD_LCD_MOSI       11
#define BOARD_LCD_MISO       13   /* -1 if unused */
#define BOARD_LCD_CS         10
#define BOARD_LCD_DC         9
#define BOARD_LCD_RST        14
#define BOARD_LCD_BL         21   /* backlight, active high via LEDC PWM */
#define BOARD_LCD_SPI_HZ     40000000
#define BOARD_LCD_W          320  /* landscape */
#define BOARD_LCD_H          240
#define BOARD_LCD_MADCTL     0x28 /* MV|BGR = landscape. Try 0xE8/0x68/0x88 to flip */
#define BOARD_LCD_INVERT     0    /* set 1 if colors look inverted */

/* Flipper UI is 128x64; scaled 2x to 256x128, centred. */
#define BOARD_UI_SCALE       2
/* Theme (RGB565): Flipper-style black ink on orange. */
#define BOARD_COLOR_BG       0xFC40  /* orange  */
#define BOARD_COLOR_FG       0x0000  /* black   */
#define BOARD_COLOR_BORDER   0x0000  /* bezel   */

/* ---- Buttons (active low, internal pull-ups) ---- */
#define BOARD_BTN_UP         4
#define BOARD_BTN_DOWN       5
#define BOARD_BTN_LEFT       6
#define BOARD_BTN_RIGHT      7
#define BOARD_BTN_OK         15
#define BOARD_BTN_BACK       16

/* ---- microSD on SPI3 (use a separate bus from the display) ---- */
#define BOARD_SD_HOST        SPI3_HOST
#define BOARD_SD_SCLK        40
#define BOARD_SD_MOSI        38
#define BOARD_SD_MISO        39
#define BOARD_SD_CS          41
#define BOARD_SD_CD          (-1) /* card-detect GPIO, -1 if none */
#define BOARD_SD_SPI_KHZ     20000
